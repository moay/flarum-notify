var gulp = require('flarum-gulp');

gulp({
  modules: {
    'notify': 'src/**/*.js'
  }
});
